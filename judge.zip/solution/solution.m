a = input("");
b = input("");
fprintf("%d\n%d" , b , a);