% my_sum.m - Function to sum two numbers
function result = my_sum(a, b)
    result = a + b;
end
