% run_my_sum.m - Calls my_sum function with predefined inputs

a = input("");
b = input("");

result = my_sum(a, b);
disp(result);
